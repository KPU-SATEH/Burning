package com.dteviot.epubviewer;

/**
 * Created by hyejin on 2017-05-25.
 */

public class Gloval {
    private static String b_name ="";

    public static String getB_name(){
        return b_name;
    }
    public static void setB_name(String a){
        Gloval.b_name = a;
    }
}
