package com.dteviot.epubviewer;

/*
 * Equivalent of a C# Action
 */
public interface IAction {
    void doAction();
}
