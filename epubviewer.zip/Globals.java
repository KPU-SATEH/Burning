package com.dteviot.epubviewer;

public class Globals {
    public static final String TAG = "SimpleEpubViewer";
    public static final String UTF8 = "UTF-8";
    public static final int WEB_SERVER_PORT = 1025;
}
