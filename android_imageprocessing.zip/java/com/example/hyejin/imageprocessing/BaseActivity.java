package com.example.hyejin.imageprocessing;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by hyejin on 2017-06-03.
 */

public class BaseActivity extends AppCompatActivity {
    protected static final String KEY_BITMAP = "IMAGE_PATH";
}
